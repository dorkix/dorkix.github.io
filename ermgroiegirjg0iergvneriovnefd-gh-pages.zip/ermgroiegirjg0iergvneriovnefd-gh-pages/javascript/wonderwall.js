var c, lyrics = [
    "Today is gonna be the day",
    "That they're gonna throw it back to you",
    "By now you should've somehow",
    "Realized what you gotta do",
    "I don't believe that anybody",
    "Feels the way I do about you now",
    "----------------------------------",
    "Back beat, the word is on the street",
    "That the fire in your heart is out",
    "I'm sure you've heard it all before",
    "But you never really had a doubt",
    "I don't believe that anybody feels",
    "The way I do about you now",
    "----------------------------------",
    "And all the roads we have to walk are winding",
    "And all the lights that lead us there are blinding",
    "There are many things that I would",
    "Like to say to you",
    "But I don't know how",
    "----------------------------------",
    "Because maybe",
    "You're gonna be the one that saves me",
    "And after all",
    "You're my wonderwall",
    "----------------------------------",
    "Today was gonna be the day",
    "But they'll never throw it back to you",
    "By now you should've somehow",
    "Realized what you're not to do",
    "I don't believe that anybody",
    "Feels the way I do",
    "About you now",
    "----------------------------------",
    "And all the roads that lead you there were winding",
    "And all the lights that light the way are blinding",
    "There are many things that I would like to say to you",
    "But I don't know how",
    "----------------------------------",
    "I said maybe",
    "You're gonna be the one that saves me",
    "And after all",
    "You're my wonderwall",
    "",
    "I said maybe",
    "You're gonna be the one that saves me",
    "And after all",
    "You're my wonderwall",
    "----------------------------------",
    "I said maybe",
    "You're gonna be the one that saves me",
    "You're gonna be the one that saves me",
    "You're gonna be the one that saves me"
];

Dubtrack.Events.bind('realtime:room_playlist-update', function(data) {
    c = -1;
    if(!strContains(data.songInfo.name, "wonderwall") || !strContains(data.songInfo.name, "oasis")) return;
    
    setInterval(function() {
        c++;
        Dubtrack.room.chat._messageInputEl.val(lyrics[c]);
        Dubtrack.room.chat.sendMessage();
        
        if(c >= lyrics.lenght) clearInterval(this);
    }, 1000);
});

function strContains(str1, str2) { return str1.toLowerCase().search(str2) > -1; }
