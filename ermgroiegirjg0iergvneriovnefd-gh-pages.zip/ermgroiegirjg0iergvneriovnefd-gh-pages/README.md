All CSS files are only tested on Google Chrome and so other browsers might not support them right.

To load on Dubtrack do on the URL:
- Replace `https://github.com/Netox005/Dubtrack` to `https://netox005.github.io/Dubtrack`
- If it contains `/blob/gh-pages` remove it
