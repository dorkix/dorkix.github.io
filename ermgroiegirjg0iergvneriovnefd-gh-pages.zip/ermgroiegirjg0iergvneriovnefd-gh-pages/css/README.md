Everything under the css directory is free to use and modify, but I always would prefer if you contacted me for whatever you're planning on using it for, in case I can help.
